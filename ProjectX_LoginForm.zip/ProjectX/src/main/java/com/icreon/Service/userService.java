package com.icreon.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.icreon.model.User;
import com.icreon.repository.userRepository;


@Service
public class userService {

	
	
	  @Autowired userRepository repo;
	 
	public User login(String username, String password) {

		User user = repo.findByUsernameAndPassword(username, password);
		return user;

	}

}
