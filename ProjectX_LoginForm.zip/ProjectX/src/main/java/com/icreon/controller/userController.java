package com.icreon.controller;

import java.util.Objects;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import com.icreon.Service.userService;
import com.icreon.model.User;
import cn.apiclub.captcha.Captcha;

@Controller
public class userController {

	
	 
	@Autowired
	userService userService;

	
	@GetMapping("/loginpage")
	public String home()
	{
		return "home.jsp";
	}
	@PostMapping("/login")
	public String login(@ModelAttribute("user") User user,HttpServletRequest request) throws Exception {

	
	User u=userService.login(user.getUsername(),user.getPassword());

		if (Objects.nonNull(u)) {
	
	
			return "login.jsp";
		} else {

			return "fail.jsp";

		}
	
	}
	
	
		  
		 
	
	
}
