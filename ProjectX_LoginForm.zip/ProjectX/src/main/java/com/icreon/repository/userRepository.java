package com.icreon.repository;

import org.springframework.data.jpa.repository.JpaRepository;


import com.icreon.model.User;

public interface userRepository  extends JpaRepository<User,String> {

	 User findByUsernameAndPassword(String username,String password);

	
}
