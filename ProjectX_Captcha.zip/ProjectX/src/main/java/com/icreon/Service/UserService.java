package com.icreon.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.icreon.model.User;
import com.icreon.repository.UserRepository;

@Service
public class UserService {

	@Autowired
	UserRepository repo;

	public User login(String username, String password) {
		User user = repo.findByUsernameAndPassword(username, password);
		return user;
	}

}
