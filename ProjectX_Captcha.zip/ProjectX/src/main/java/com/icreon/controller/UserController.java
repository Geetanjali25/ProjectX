package com.icreon.controller;

import java.util.Objects;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.icreon.Service.UserService;
import com.icreon.captcha.CaptchaUtils;
import com.icreon.model.User;

import cn.apiclub.captcha.Captcha;

@Controller
public class UserController {

	@Autowired
	UserService userService;

	private void createCaptcha(Model model) {
		User user = new User();
		Captcha captcha = CaptchaUtils.createCaptcha(200, 50);
		user.setHidden(captcha.getAnswer());
		user.setCaptcha("");
		user.setImage(CaptchaUtils.encodeBase64(captcha));
		model.addAttribute("user", user);
	}
	
	@GetMapping("/loginpage")
	public ModelAndView home(Model model) {
		ModelAndView modelAndView = new ModelAndView("login");
		createCaptcha(model);
		return modelAndView;
	}

	@PostMapping("/loginPost")
	public ModelAndView login(@ModelAttribute("user") User user, Model model) throws Exception {

		if (user.getCaptcha().equals(user.getHidden()) && user.getUsername() != null && user.getPassword() != null) {
			User u = userService.login(user.getUsername(), user.getPassword());
			if (Objects.nonNull(u)) {
				return new ModelAndView("welcome");
			} else {
				return new ModelAndView("fail");
			}
		} else {
			createCaptcha(model);
			return new ModelAndView("login");
		}

	}

}
